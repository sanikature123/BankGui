﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L8PEF1G\SQLEXPRESS04;Initial Catalog=bankk;Integrated Security=True");
            con.Open();
            string depositQuery="INSERT INTO Bkk_1(name,address,balance,accoNo,"+"date,deposit) VALUES(@name,@add,@balance,@acc,@date,@deposit)";
            SqlCommand cmd=new SqlCommand(depositQuery,con);
            cmd.Parameters.AddWithValue("@name",textBox1.Text);
            cmd.Parameters.AddWithValue("@add",textBox2.Text);
            cmd.Parameters.AddWithValue("@balance",textBox3.Text);
            cmd.Parameters.AddWithValue("@date",dtDate.Text);
            cmd.Parameters.AddWithValue("@deposit",textBox3.Text);

            string accoNO=AccoNo();
            cmd.Parameters.AddWithValue("@acc",accoNO);
            int count = cmd.ExecuteNonQuery();
            con.Close();
            if(count > 0)
            {
                MessageBox.Show("deposited sussesfully","info",MessageBoxButtons.OK,MessageBoxIcon.Information);


            }
        }

        private string AccoNo()
        {
            string startWith="1280";
            Random random=new Random();
            string gen=random.Next(0,999999).ToString("D6");
        string accoNo=startWith +gen;
            return accoNo;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int balance=0;
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L8PEF1G\SQLEXPRESS04;Initial Catalog=bankk;Integrated Security=True");
            con.Open();
            string readQuery = "SELECT *FROM Bkk_1 WHERE accoNo=@acc";
            SqlCommand cmd=new SqlCommand(readQuery,con);
            cmd.Parameters.AddWithValue("@acc",textBox4.Text);
            int count=Convert.ToInt32(cmd.ExecuteScalar());
            if (count > 0)
            {
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    balance = Convert.ToInt32(reader["balance"]);
                }
                reader.Close();
                if (balance > 0 && balance > Convert.ToInt32(textBox3.Text))
                {
                    int newBalance = balance - int.Parse(textBox3.Text);
                    string updateQuery = "UPDATE Bkk_1 SET balance=@balance,withdraw=@with" + " WHERE accoNo=@accno";
                    SqlCommand cmdup = new SqlCommand(updateQuery, con);
                    cmdup.Parameters.AddWithValue("@balance", newBalance);
                    cmdup.Parameters.AddWithValue("@with", textBox3.Text);
                    cmdup.Parameters.AddWithValue("@accno", textBox4.Text);
                    cmdup.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("remaining balance" + newBalance);
                }

                else
                {
                    MessageBox.Show("insufficiant ammount", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            else
            {
                MessageBox.Show("account not found", "error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-L8PEF1G\SQLEXPRESS04;Initial Catalog=bankk;Integrated Security=True");
            con.Open();
            string selectQuery="SELECT * FROM Bkk_1 WHERE accoNo=@acc";
            SqlCommand cmd=new SqlCommand(selectQuery,con);
            cmd.Parameters.AddWithValue("@acc",textBox4.Text);
            SqlDataReader reader=cmd.ExecuteReader();
            while (reader.Read())
            {
                textBox1.Text=reader["name"].ToString();
                textBox2.Text=reader["address"].ToString();
                textBox3.Text=reader["balance"].ToString();

            }
            reader.Close();
            con.Close();
            dtDate.Enabled=false;

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}
